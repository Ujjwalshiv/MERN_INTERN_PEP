function handleClick(){
    var ele = document.querySelector("h1");
    console.log(ele)
    ele.style.color ="white"
}