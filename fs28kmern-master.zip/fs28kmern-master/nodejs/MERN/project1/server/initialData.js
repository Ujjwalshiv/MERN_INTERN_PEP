var studentArray = [{
    id: 1,
    name: 'Jayesh',
    currentClass: 5,
    division: 'A'
},
{
    id: 2,
    name: 'Minakshi',
    currentClass: 12,
    division: 'C'
},
{
    id: 3,
    name: 'Drisham',
    currentClass: 7,
    division: 'C'
},
{
    id: 4,
    name: 'Kamlesh',
    currentClass: 7,
    division: 'A'
},
{
    id: 5,
    name: 'Dhoni',
    currentClass: 10,
    division: 'D'
},
{
    id: 6,
    name: 'Piyush',
    currentClass: 10,
    division: 'A'
},
{
    id: 7,
    name: 'Aansh',
    currentClass: 8,
    division: 'A'
}]
module.exports=studentArray;