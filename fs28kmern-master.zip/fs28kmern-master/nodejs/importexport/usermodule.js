// export function sum(x,y){
//     return x+y
// }
module.exports.add = function(x,y){
    return x+y
}
module.exports.sub = function(x,y){
    return x-y
}