import React from 'react'

export default function Ceo() {
  return (
    <div>
        <h1>CEO contact details</h1>
    </div>
  )
}
