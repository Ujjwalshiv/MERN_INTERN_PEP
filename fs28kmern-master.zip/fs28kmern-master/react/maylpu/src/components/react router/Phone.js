import React from 'react'

export default function Phone() {
  return (
    <div>Phone</div>
  )
}
