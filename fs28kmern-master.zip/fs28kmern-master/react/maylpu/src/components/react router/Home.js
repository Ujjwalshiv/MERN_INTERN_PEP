import React from 'react'


export default function Home() {
  return (
    <div>
      <h1>Welcome to my website!</h1>
      <mark>Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe eligendi error quam culpa, iste sint quidem ipsum quis voluptatem vel.</mark>
      <small>ushdguhduh</small>
    </div>
  )
}
