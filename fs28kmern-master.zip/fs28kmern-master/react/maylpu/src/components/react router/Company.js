import React from 'react'

export default function Company() {
  return (
    <div>
        <h1>Company Contact details</h1>
    </div>
  )
}
