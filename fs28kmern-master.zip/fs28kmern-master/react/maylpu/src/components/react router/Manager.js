import React from 'react'

export default function Manager() {
  return (
    <div>
        <h1>Manager contact details</h1>
    </div>
  )
}
