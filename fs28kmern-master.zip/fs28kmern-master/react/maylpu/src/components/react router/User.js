import React from 'react'

export default function User() {
  return (
    <div>
        <h1>
        All user details
        </h1>
    </div>
  )
}
