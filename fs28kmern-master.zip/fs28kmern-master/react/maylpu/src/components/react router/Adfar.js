import React from 'react'

export default function Adfar() {
  return (
    <div>
      Adfar</div>
  )
}
