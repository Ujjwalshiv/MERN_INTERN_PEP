import React from 'react'
import mystyle from "./File3.module.css"
export default function File3() {
  return (
    <div className={mystyle.container3}>
        <h1 className={mystyle.heading3}>This is my file 3 heading</h1>
        <h1 className={mystyle.heading1}>This is my file 3 heading</h1>
    </div>
  )
}
