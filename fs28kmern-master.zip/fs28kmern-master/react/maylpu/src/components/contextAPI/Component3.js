import React from 'react'
import Component4 from './Component4'

export default function Component3() {
  return (
    <div>
        <Component4/>
    </div>
  )
}
