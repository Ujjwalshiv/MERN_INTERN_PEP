import React from 'react'
import Component2 from './Component2'

export default function Component1() {
  return (
    <div>
        <Component2/>
    </div>
  )
}
