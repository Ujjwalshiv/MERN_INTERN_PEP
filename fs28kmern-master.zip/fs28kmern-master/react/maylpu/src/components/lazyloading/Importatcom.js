import React from 'react'

export default function Importatcom() {
  return (
    <div>
        <h1>Importatcom</h1>
    </div>
  )
}
