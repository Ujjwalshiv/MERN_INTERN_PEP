import React from 'react'

export default function Component2() {
  return (
    <div>
        <h1>Component 2</h1>
        <h1>Component 2</h1>
        <h1>Component 2</h1>
        <h1>Component 2</h1>
        <h1>Component 2</h1>
        <h1>Component 2</h1>
        <h1>Component 2</h1>
        <h1>Component 2</h1>
        <h1>Component 2</h1>
    </div>
  )
}
