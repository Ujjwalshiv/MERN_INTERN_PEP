import React, { useEffect } from 'react'

export default function CWumount() {
    useEffect(()=>{
        console.log('UnMount')
    })
  return (
    <div>CWumount</div>
  )
}
