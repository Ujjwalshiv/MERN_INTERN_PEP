import React from 'react'

function News({children}) {
  return (
    <div>
        <h1>sgdfghs</h1>
        {children}
    </div>
  )
}

export default News