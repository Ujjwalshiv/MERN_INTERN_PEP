import React from 'react'

function Section(props) {
  return (
    <div>
         <h1>My lastname is: {props.lName}</h1>
    </div>
  )
}

export default Section