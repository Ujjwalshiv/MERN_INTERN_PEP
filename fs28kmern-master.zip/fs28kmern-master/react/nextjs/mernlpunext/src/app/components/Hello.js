"use client"
import React, { useEffect } from 'react'

export default function Hello() {
    useEffect(()=>{
        console.log("Adfar")
    })
  return (
    <div>Hello</div>
  )
}
