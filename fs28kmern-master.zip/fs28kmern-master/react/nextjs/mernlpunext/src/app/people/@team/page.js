import React from 'react'

export default function team() {
  return (
    <div>team</div>
  )
}
