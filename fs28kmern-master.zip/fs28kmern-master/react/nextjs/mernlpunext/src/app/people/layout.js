"use client"
import React from 'react'

export default function peoplelayout({analytics,team}) {
    const condition = true;
    console.log(analytics)
  return (
    <div>
        
        
       {team}
        <h1>People Layout</h1>
    </div>
  )
}
