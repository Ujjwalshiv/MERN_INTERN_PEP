import React from 'react'

export default function analytics() {
  return (
    <div>analytics</div>
  )
}
