import React from 'react'

export default function peoplepage() {
  return (
    <div>
        <h1>People page</h1>
    </div>
  )
}
