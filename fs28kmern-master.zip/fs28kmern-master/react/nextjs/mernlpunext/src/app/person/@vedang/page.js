import React from 'react'

export default function vedang() {
  return (
    <div>vedang</div>
  )
}
