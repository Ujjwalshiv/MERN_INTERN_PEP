import React from 'react'

export default function person() {
  return (
    <div>person</div>
  )
}
