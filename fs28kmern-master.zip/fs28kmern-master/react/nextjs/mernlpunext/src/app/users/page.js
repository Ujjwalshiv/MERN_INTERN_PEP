import React from 'react'

export default function userpage() {
  return (
    <div>
        <h1>User Page</h1>
    </div>
  )
}
