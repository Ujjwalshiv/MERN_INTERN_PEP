import React from 'react'

export default function coursespage() {
  return (
    <div>
        <h1>Courses page</h1>
    </div>
  )
}
