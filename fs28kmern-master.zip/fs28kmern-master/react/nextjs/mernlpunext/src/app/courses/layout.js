import React from 'react'

export default function courselayout({children}) {
  return (
    <div>
        {children}
        <h1>Courses layout</h1>
    </div>
  )
}
