import React from 'react'

export default function menpage() {
  return (
    <div>
        <h2>Men shop page</h2>
    </div>
  )
}
