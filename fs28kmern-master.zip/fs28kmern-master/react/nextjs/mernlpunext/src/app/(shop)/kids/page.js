import React from 'react'

export default function kidpage() {
  return (
    <div>
        <h3>kids shop page</h3>
    </div>
  )
}
