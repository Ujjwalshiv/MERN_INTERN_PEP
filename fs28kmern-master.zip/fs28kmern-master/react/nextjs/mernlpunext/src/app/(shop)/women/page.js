import React from 'react'

export default function womenpage() {
  return (
    <div>
        <h3>Women shop page</h3>
    </div>
  )
}
