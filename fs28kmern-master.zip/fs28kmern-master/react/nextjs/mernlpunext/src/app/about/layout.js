import React from 'react'

export default function Aboutlayout({children}) {
  return (
    <div>
        {children}
        <h1>About shared UI</h1>
    </div>
  )
}
