import React from 'react'

export default function adfarpage() {
  return (
    <div>
        <h1>About Adfar rashiid</h1>
    </div>
  )
}
