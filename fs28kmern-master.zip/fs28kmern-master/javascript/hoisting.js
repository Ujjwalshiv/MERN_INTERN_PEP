// console.log(a)
// greet()
// var a =10;
// function greet(){
//     console.log("ADfar")
// }
// var a;
// console.log("adfar")
// console.log("adfar")
// console.log("adfar")
// console.log("adfar")
// console.log("adfar")
// console.log("adfar")
// console.log("adfar")
// console.log("adfar")
// console.log("adfar")
// console.log("adfar")
// console.log("adfar")
// console.log("adfar")
// console.log("adfar")
// console.log("adfar")
// // var a = 10;
// a=10;

let a =10;
{
    console.log(a)
    let a =30;
    console.log(a)
}