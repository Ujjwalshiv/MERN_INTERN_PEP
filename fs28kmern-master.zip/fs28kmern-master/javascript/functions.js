function greet(x,y,z){
    console.log(x*2*z*y)
}
greet(4,6,7)
greet(6,3,4)
