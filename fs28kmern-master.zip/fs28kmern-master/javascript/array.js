var arr = [2,3,4,"adfar",true,null,6,6,78]
var arr2 = [
    [1,2,3],
    [4,5,6],
    [7,8,9],
    6,"dfdf","ygjft",true
]
console.log(arr2[1][1])