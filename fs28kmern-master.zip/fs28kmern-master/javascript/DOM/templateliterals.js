let str = "Adfar Rasheed"
let str2 = "good morning";
let para = "Hey " + str2 + " My name is " + str + " and i am an instructor";
 let para2 = `Hey ${str2} My name is ${str} and i am an instructor`
console.log(para2)