var a = 10;
var b = "20a";
console.log( a +b)
console.log( a - b)
console.log( a * b)
console.log( a / b)
console.log( a % b)
var d = +b;
console.log(d)
console.log(isNaN("dfg"))