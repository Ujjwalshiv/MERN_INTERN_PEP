// for(0;-10;0){
//     console.log("Adfar")
// }
// let a =20
// while(a>10){
//     console.log("adafar");
//     a--;
// }
let a =20
do {
 console.log("adfar");
 a++;
} while (a<20)