// // var a =10;
// // console.log(a)
// // var a = "adfar";
// // console.log(a);
// // a= true;
// // console.log(a)
// // let a = 10;
// // console.log(a);
// // a ="adfar";
// // console.log(a);

// // const a = 10;
// // a =20;
// // console.log(a);
// // const a;

// // console.log(a)

// // var a = 10;
// // var b = "10";
// // var c =true;
// // var a =31245643245643223453556432n;
// // console.log(a)
// // console.log(typeof(a))


// var a =13;
// var b = 5;
// console.log( a> b || a<3)
// console.log(a==b)
// console.log(a===b)
// console.log(a!=b)
// console.log(a!==b)
// console.log(a & b)
// console.log(a | b)
// console.log(a ^ b)

var a =10;
console.log(a++)
console.log(++a)
console.log(--a)
console.log(a--)