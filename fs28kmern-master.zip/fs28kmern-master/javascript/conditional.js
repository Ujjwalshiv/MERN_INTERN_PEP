var a =11.5;
if(a>0){
    console.log("A is positive")
} else if(a%2==0){
    console.log("a is a negative even number")
} else{
    console.log("a is not vhgsdhgfyt")
}
console.log(a>10?"a is greater":"a is not");

switch(a){
    case 1:
        console.log("a is 1");
        break;
    case 10:
        console.log("a is 10");
        break;
    case 11.5:
        console.log("a is 21");
        break;
    default:
        console.log("sgfdfghd")
    
}