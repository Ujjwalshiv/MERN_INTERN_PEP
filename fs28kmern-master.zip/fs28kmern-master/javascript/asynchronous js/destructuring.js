// var obj = {
//     firstName:"Adfar",
//     lastName:"rashid",
//     age:0
// }
// var {firstName} = obj
// console.log(firstName)
// // console.log(lastName)