//function statement
// greet()
// function greet(){
//     return "Good morning"
// } 
// console.log(greett)
// var greett = function (){
//    console.log("Hello ")
//    return 3
// }
// greett()
// (function(x,y,z){
//     console.log(x+y+z)
// }(3,5,82))

// var greet = function(x,y){
//     return x+y;
// }
// var greet =(x,y)=>{
//    return x+y
// }
// console.log(greet(3,4))
// var greet = function(x){
//     return x*2
// }
// var greet = ()=>x*2