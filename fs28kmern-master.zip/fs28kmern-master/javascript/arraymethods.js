// arr.push("ADfar",5,3,423,2,32,3)
// console.log(arr);
// console.log(arr.pop())
// console.log(arr)
// console.log(arr.shift())
// console.log(arr)
// arr.unshift("2")
// console.log(arr)
// var arr1 = arr.slice(3)
// console.log(arr1)
// var arr = ["a",3,4,56,3,24,3,9];
// console.log(arr.splice(2,0,"a","r","t"))
// var str = "Adfar Rashid is the instructor "
// var arr3 =str.split(" ")
// console.log(arr3)

// var arr1= [1,2,3];
// var arr2 = [4,5,6];
// var arr3 = [7,8,9];
// var arr4 = [].concat(arr1,arr2,arr3)
// console.log(arr4)

var arr = [1,2,[2,[4,[5]]],5,6,7,[8],[[8,9]],[[[[[[[[6]]]]]]]]]
var ar2= arr.flat(Infinity)
console.log(ar2)