var adfar = {
    name:"Adfar",
    age:28,
    salary:5000
}
// console.log(adfar.age)
console.log(adfar["name"])
console.log(adfar["age"])